package com.usa.ciclo4_reto2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ciclo4Reto2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
