package com.usa.ciclo4_reto2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ciclo4Reto2Application {

    public static void main(String[] args) {
        SpringApplication.run(Ciclo4Reto2Application.class, args);
    }

}
